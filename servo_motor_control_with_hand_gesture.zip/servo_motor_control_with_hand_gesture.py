import cv2
import numpy as np
import mediapipe as mp
import math
import pyfirmata2
import time

# Initialize the MediaPipe hand detection model
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False, max_num_hands=2, min_detection_confidence=0.5, min_tracking_confidence=0.5)

# Initialize the video capture from the front-facing camera
cap = cv2.VideoCapture(1)

# Initialize the Arduino board and the servo motor pin
try:
    board = pyfirmata2.Arduino('COM3')
    servo_pin = board.get_pin('d:10:s')
except pyfirmata2.pyfirmata2.PyFirmataError as e:
    print(f"Error: {e}")
    exit()

# Initialize the servo motor position and direction
servo_position = 90
servo_direction = 1
is_index_thumb_touching = False
is_little_thumb_touching = False

while True:
    # Capture a frame from the video stream
    ret, frame = cap.read()

    if ret:
        # Convert the frame to RGB format for MediaPipe
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        # Detect the hands in the frame using MediaPipe
        results = hands.process(rgb_frame)

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                # Get the coordinates of the hand landmarks
                hand_landmark_list = []
                for landmark in hand_landmarks.landmark:
                    hand_landmark_list.append((int(landmark.x * frame.shape[1]), int(landmark.y * frame.shape[0])))

                # Check if the index finger and thumb are touching
                index_thumb_distance = np.linalg.norm(np.array(hand_landmark_list[8]) - np.array(hand_landmark_list[4]))
                is_index_thumb_touching = index_thumb_distance < 50

                # Check if the little finger and thumb are touching
                little_thumb_distance = np.linalg.norm(np.array(hand_landmark_list[20]) - np.array(hand_landmark_list[4]))
                is_little_thumb_touching = little_thumb_distance < 50

                # Control the servo motor based on the hand gestures
                if is_index_thumb_touching:
                    # Rotate the servo motor to 180 degrees
                    servo_position = 180
                    servo_pin.write(servo_position)
                elif is_little_thumb_touching:
                    # Rotate the servo motor back and forth infinitely
                    servo_position += servo_direction * 5
                    if servo_position >= 180 or servo_position <= 0:
                        servo_direction *= -1
                    servo_pin.write(servo_position)
                else:
                    # Stop the servo motor
                    servo_position = 90
                    servo_pin.write(servo_position)

                # Draw the hand landmarks and the fingers with different colors
                for i, point in enumerate(hand_landmarks.landmark):
                    if i in [4, 8, 12, 16, 20]:  # Index fingers
                        color = (255, 0, 0)  # Blue
                    elif i in [3, 7, 11, 15, 19]:  # Thumb, middle, ring, little fingers
                        color = (0, 255, 0)  # Green
                    else:
                        color = (0, 0, 255)  # Red
                    x = int(point.x * frame.shape[1])
                    y = int(point.y * frame.shape[0])
                    cv2.circle(frame, (x, y), 5, color, -1)

                # Draw the hand edge contours
                hand_edge_contour = np.array([hand_landmark_list], dtype=np.int32)
                cv2.polylines(frame, [hand_edge_contour], True, (0, 255, 255), 2)

        # Display the frame
        cv2.imshow('Hand Gesture Detection', frame)

        # Exit the loop if the 'q' key is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    else:
        break

# Release the video capture, close the Arduino board, and close all windows
cap.release()
board.exit()
cv2.destroyAllWindows()